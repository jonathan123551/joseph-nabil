# Tickets System

A Laravel-based event/ticket management system with a public booking flow and an admin dashboard. Approved bookings receive a QR-coded ticket on WhatsApp via the Meta Cloud API.

## Features

### Public
- Browse events and show times
- Book tickets (name + phone) — no login required

### Admin
- Create / edit / delete events (shows)
- Manage show times, prices and available tickets
- Review pending bookings, approve or reject
- On approval, a personalised QR ticket is generated and sent to the booker's WhatsApp
- Built-in QR scanner for verification at the gate

## Tech Stack

- Laravel 12 (PHP 8.2+)
- Tailwind CSS (CDN)
- Cloudinary for image hosting (with local fallback)
- `endroid/qr-code` for ticket QR generation
- Meta WhatsApp Cloud API for ticket delivery
- SQLite by default (PostgreSQL supported via `DB_URL` for production)

## Setup

```bash
cp .env.example .env
composer install
php artisan key:generate
php artisan migrate
php artisan serve
```

### Required environment variables

```
APP_NAME=Tickets
APP_URL=http://localhost:8000

ADMIN_EMAIL=admin@example.com   # Email allowed to access /admin

# WhatsApp Cloud API
WHATSAPP_TOKEN=
WHATSAPP_PHONE_ID=
WHATSAPP_VERIFY_TOKEN=          # for the /webhook/whatsapp endpoint

# Cloudinary (optional)
CLOUDINARY_CLOUD_NAME=
CLOUDINARY_API_KEY=
CLOUDINARY_API_SECRET=
```

## Routes (high level)

| Method | URL                                  | Purpose                  |
|--------|--------------------------------------|--------------------------|
| GET    | `/`                                  | Public events list       |
| GET    | `/shows/{show}`                      | Event details            |
| GET    | `/book/{showTime}`                   | Booking form             |
| POST   | `/book/{showTime}`                   | Submit booking (pending) |
| GET    | `/login`                             | Admin login              |
| GET    | `/admin`                             | Dashboard                |
| GET    | `/admin/shows`                       | Manage events            |
| GET    | `/admin/bookings`                    | Review bookings          |
| POST   | `/admin/bookings/{booking}/approve`  | Approve & send WhatsApp  |
| POST   | `/admin/bookings/{booking}/reject`   | Reject                   |
| GET    | `/admin/scanner`                     | QR scanner               |
| GET/POST | `/webhook/whatsapp`               | Meta WhatsApp webhook    |

## Booking flow

1. User picks a show time and submits a booking with name(s) and phone(s).
2. Booking is stored with `status = pending`.
3. Admin reviews the booking from `/admin/bookings`.
4. On **Approve**, the system generates a QR-coded ticket per attendee and sends it to the booker's WhatsApp.
5. At the venue, the admin uses `/admin/scanner` to verify each ticket QR.

## License

MIT
