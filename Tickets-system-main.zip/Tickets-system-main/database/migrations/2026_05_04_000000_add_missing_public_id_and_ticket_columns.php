<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Add the columns that the application code (controllers + models) was
     * already referencing but were never declared on the corresponding
     * tables. Without these, a freshly-migrated database will throw
     * "table X has no column named Y" errors as soon as the user creates
     * a show or submits a booking.
     */
    public function up(): void
    {
        Schema::table('shows', function (Blueprint $table) {
            if (! Schema::hasColumn('shows', 'poster_public_id')) {
                $table->string('poster_public_id')->nullable()->after('poster_path');
            }
            if (! Schema::hasColumn('shows', 'ticket_template_public_id')) {
                $table->string('ticket_template_public_id')->nullable()->after('ticket_template_path');
            }
        });

        Schema::table('bookings', function (Blueprint $table) {
            if (! Schema::hasColumn('bookings', 'transfer_screenshot_public_id')) {
                $table->string('transfer_screenshot_public_id')->nullable()->after('transfer_screenshot_path');
            }
            if (! Schema::hasColumn('bookings', 'qr_code_public_id')) {
                $table->string('qr_code_public_id')->nullable()->after('qr_code_path');
            }
        });

        Schema::table('tickets', function (Blueprint $table) {
            if (! Schema::hasColumn('tickets', 'name')) {
                $table->string('name')->nullable()->after('booking_id');
            }
            if (! Schema::hasColumn('tickets', 'phone')) {
                $table->string('phone')->nullable()->after('name');
            }
            if (! Schema::hasColumn('tickets', 'whatsapp_sent')) {
                $table->boolean('whatsapp_sent')->default(false);
            }
        });

        // qr_image_path was created NOT NULL but is only populated later
        // by Admin\BookingController::approve(). Booking submission can't
        // supply it, so make it nullable to match runtime usage.
        if (Schema::hasColumn('tickets', 'qr_image_path')) {
            Schema::table('tickets', function (Blueprint $table) {
                $table->string('qr_image_path')->nullable()->change();
            });
        }

        // show_times.available_tickets was declared NOT NULL but
        // ShowTimeController::store() never supplies it (the field on
        // the admin form is optional). Make it nullable so leaving the
        // form field blank doesn't 500 on insert.
        if (Schema::hasColumn('show_times', 'available_tickets')) {
            Schema::table('show_times', function (Blueprint $table) {
                $table->unsignedInteger('available_tickets')->nullable()->change();
            });
        }
    }

    public function down(): void
    {
        Schema::table('shows', function (Blueprint $table) {
            $table->dropColumn(['poster_public_id', 'ticket_template_public_id']);
        });

        Schema::table('bookings', function (Blueprint $table) {
            $table->dropColumn(['transfer_screenshot_public_id', 'qr_code_public_id']);
        });

        Schema::table('tickets', function (Blueprint $table) {
            $table->dropColumn(['name', 'phone', 'whatsapp_sent']);
        });
    }
};
