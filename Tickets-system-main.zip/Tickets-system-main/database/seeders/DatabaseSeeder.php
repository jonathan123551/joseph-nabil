<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * Creates an admin user using ADMIN_EMAIL and ADMIN_PASSWORD env vars when
     * provided, so the dashboard is reachable on a fresh install. Defaults are
     * suitable for local development only.
     */
    public function run(): void
    {
        $email    = env('ADMIN_EMAIL', 'admin@example.com');
        $password = env('ADMIN_PASSWORD', 'password');

        User::updateOrCreate(
            ['email' => $email],
            [
                'name'              => 'Admin',
                'password'          => Hash::make($password),
                'email_verified_at' => now(),
            ]
        );
    }
}
