<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class IsAdmin
{
    public function handle(Request $request, Closure $next)
    {
        if (! auth()->check()) {
            return redirect()->route('login');
        }

        $adminEmail = config('auth.admin_email');

        if ($adminEmail && auth()->user()->email !== $adminEmail) {
            abort(403, 'غير مصرح لك بدخول لوحة التحكم.');
        }

        return $next($request);
    }
}
