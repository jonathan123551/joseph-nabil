<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\Show;
use App\Models\ShowTime;

class DashboardController extends Controller
{
    public function index()
    {
        $totalShows     = Show::count();
        $totalShowTimes = ShowTime::count();

        $totalTicketsAllTimes = ShowTime::sum('total_tickets');

        $bookedPendingApproved = Booking::whereIn('status', ['pending', 'approved'])
            ->sum('tickets_count');

        $ticketsRemaining = max($totalTicketsAllTimes - $bookedPendingApproved, 0);

        $totalTicketsApproved = Booking::where('status', 'approved')
            ->sum('tickets_count');

        $pendingBookings  = Booking::where('status', 'pending')->count();
        $rejectedBookings = Booking::where('status', 'rejected')->count();

        $showTimesStats = ShowTime::with('show')
            ->orderBy('date')
            ->orderBy('time')
            ->get();

        foreach ($showTimesStats as $time) {
            $approved = Booking::where('show_time_id', $time->id)
                ->where('status', 'approved')
                ->sum('tickets_count');

            $pending = Booking::where('show_time_id', $time->id)
                ->where('status', 'pending')
                ->sum('tickets_count');

            $remaining = $time->total_tickets - ($approved + $pending);
            if ($remaining < 0) {
                $remaining = 0;
            }

            $time->approved_tickets  = $approved;
            $time->pending_tickets   = $pending;
            $time->remaining_tickets = $remaining;
        }

        return view('admin.dashboard', compact(
            'totalShows',
            'totalShowTimes',
            'ticketsRemaining',
            'totalTicketsApproved',
            'pendingBookings',
            'rejectedBookings',
            'showTimesStats'
        ));
    }
}
