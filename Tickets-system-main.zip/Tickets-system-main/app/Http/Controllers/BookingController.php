<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\ShowTime;
use App\Models\Ticket;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;

class BookingController extends Controller
{
    public function create(ShowTime $showTime)
    {
        $reserved = $showTime->bookings()
            ->whereIn('status', ['approved', 'pending'])
            ->sum('tickets_count');

        $remaining = max(0, $showTime->total_tickets - $reserved);

        abort_if($remaining <= 0 || $showTime->is_sold_out, 404);

        return view('bookings.create', [
            'showTime'  => $showTime,
            'remaining' => $remaining,
        ]);
    }

    public function store(Request $request, ShowTime $showTime)
    {
        $lockKey = 'booking_lock_' . sha1(
            $request->ip() . json_encode($request->phones ?? []) . $showTime->id
        );

        if (! Cache::add($lockKey, true, 20)) {
            return back()->withErrors([
                'general' => '⏳ الطلب قيد المعالجة بالفعل',
            ])->withInput();
        }

        try {
            $request->validate([
                'names'     => ['required', 'array', 'min:1'],
                'names.*'   => ['required', 'string', 'max:255'],
                'phones'    => ['required', 'array', 'min:1'],
                'phones.*'  => ['required', 'string', 'min:8', 'max:20'],
            ]);

            $reserved = $showTime->bookings()
                ->whereIn('status', ['approved', 'pending'])
                ->sum('tickets_count');

            $remaining = max(0, $showTime->total_tickets - $reserved);

            $ticketsCount = count($request->names);

            if ($ticketsCount > $remaining) {
                return back()->withErrors([
                    'general' => '❌ المتاح فقط: ' . $remaining . ' تذاكر',
                ])->withInput();
            }

            if ($remaining <= 0) {
                return back()->withErrors([
                    'general' => '❌ لا توجد تذاكر متاحة',
                ])->withInput();
            }

            $mainPhone = $this->normalizeEgyptPhone($request->phones[0]);

            $booking = Booking::create([
                'show_time_id'   => $showTime->id,
                'full_name'      => $request->names[0],
                'phone'          => $mainPhone,
                'tickets_count'  => $ticketsCount,
                'total_price'    => $showTime->ticket_price * $ticketsCount,
                'status'         => 'pending',
                'reference_code' => 'SRC-' . now()->format('Ymd') . '-' . Str::upper(Str::random(6)),
            ]);

            foreach ($request->names as $i => $name) {
                Ticket::create([
                    'booking_id'  => $booking->id,
                    'name'        => $name,
                    'phone'       => $this->normalizeEgyptPhone($request->phones[$i]),
                    'ticket_code' => 'TIC-' . strtoupper(Str::random(6)),
                ]);
            }

            return view('bookings.thankyou', compact('booking'));
        } finally {
            Cache::forget($lockKey);
        }
    }

    private function normalizeEgyptPhone(string $phone): string
    {
        $phone = preg_replace('/[^0-9]/', '', $phone);

        if (preg_match('/^01[0-9]{9}$/', $phone)) {
            return '20' . substr($phone, 1);
        }

        if (preg_match('/^1[0-9]{9}$/', $phone)) {
            return '20' . $phone;
        }

        return $phone;
    }
}
