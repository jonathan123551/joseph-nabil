@extends('layouts.app')

@section('title', 'تم الحجز')

@section('content')
<section class="max-w-md mx-auto text-center space-y-6 py-10">

    <div class="inline-flex w-20 h-20 rounded-full items-center justify-center
                bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 mx-auto">
        <svg viewBox="0 0 24 24" class="w-10 h-10" fill="none" stroke="currentColor"
             stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M20 6 9 17l-5-5"/>
        </svg>
    </div>

    <div>
        <h1 class="text-2xl font-bold mb-2">تم استلام طلبك</h1>
        <p class="text-sm text-slate-300 leading-relaxed">
            حجزك في انتظار اعتماد الإدارة. هتوصلك التذكرة مع كود الـ QR على واتساب فور الموافقة.
        </p>
    </div>

    <div class="card rounded-2xl p-5 text-right">
        <div class="text-xs text-slate-400 mb-1">رقم الحجز المرجعي</div>
        <div class="font-mono text-lg text-brand-300">{{ $booking->reference_code }}</div>

        <div class="mt-4 grid grid-cols-2 gap-3 text-sm">
            <div>
                <div class="text-[11px] text-slate-400">عدد التذاكر</div>
                <div class="font-semibold">{{ $booking->tickets_count }}</div>
            </div>
            <div>
                <div class="text-[11px] text-slate-400">الإجمالي</div>
                <div class="font-semibold">{{ number_format($booking->total_price, 0) }} جنيه</div>
            </div>
        </div>
    </div>

    <a href="{{ route('shows.index') }}"
       class="btn-primary inline-flex px-5 py-2.5 rounded-xl text-sm font-semibold">
        رجوع للعروض
    </a>
</section>
@endsection
