@extends('layouts.app')

@section('title', 'حجز - ' . $showTime->show->title)

@section('content')
<section class="max-w-2xl mx-auto space-y-6">

    <a href="{{ route('shows.show', $showTime->show) }}"
       class="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-white">
        <svg viewBox="0 0 24 24" class="w-3 h-3" fill="none" stroke="currentColor"
             stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M5 12h14M12 5l7 7-7 7"/>
        </svg>
        رجوع
    </a>

    <div class="card rounded-2xl p-5">
        <h1 class="text-xl font-bold mb-2">{{ $showTime->show->title }}</h1>
        <div class="flex flex-wrap gap-2 text-xs text-slate-300">
            <span class="px-3 py-1 rounded-full bg-white/5 border border-white/10">
                {{ \Carbon\Carbon::parse($showTime->date)->format('d/m/Y') }}
            </span>
            <span class="px-3 py-1 rounded-full bg-white/5 border border-white/10">
                {{ \Carbon\Carbon::parse($showTime->time)->format('g:i A') }}
            </span>
            <span class="px-3 py-1 rounded-full bg-brand-500/15 border border-brand-500/30 text-brand-300 font-semibold">
                {{ $showTime->ticket_price }} جنيه / تذكرة
            </span>
            <span class="px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-200">
                متاح: {{ $remaining }}
            </span>
        </div>
    </div>

    <div class="card rounded-2xl p-5 md:p-6">
        <h2 class="text-base font-semibold mb-4">بيانات الحاجز</h2>

        @if ($errors->any())
            <div class="mb-4 bg-rose-500/10 border border-rose-500/40 text-rose-200 text-xs rounded-xl p-3">
                <ul class="space-y-1">
                    @foreach ($errors->all() as $error)
                        <li>• {{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('bookings.store', $showTime) }}" method="POST" id="bookingForm" class="space-y-4">
            @csrf

            <div class="bg-white/5 border border-white/10 rounded-xl p-4 flex items-center justify-between">
                <div>
                    <div class="text-sm font-semibold">عدد التذاكر</div>
                    <div class="text-[11px] text-slate-400">حد أقصى {{ min(10, $remaining) }} تذكرة</div>
                </div>
                <div class="flex items-center gap-2">
                    <button type="button" onclick="changeCount(-1)"
                            class="w-9 h-9 rounded-lg bg-white/10 hover:bg-white/20 transition text-lg leading-none">−</button>
                    <span id="ticketsCount" class="w-8 text-center font-bold">1</span>
                    <button type="button" onclick="changeCount(1)"
                            class="w-9 h-9 rounded-lg bg-white/10 hover:bg-white/20 transition text-lg leading-none">+</button>
                </div>
            </div>

            <div id="namesContainer" class="space-y-3"></div>

            <div class="flex items-center justify-between bg-brand-500/10 border border-brand-500/30 rounded-xl px-4 py-3">
                <span class="text-xs text-brand-200">المجموع</span>
                <span class="text-lg font-bold text-brand-100">
                    <span id="totalPrice">{{ $showTime->ticket_price }}</span>
                    <span class="text-sm font-normal">جنيه</span>
                </span>
            </div>

            <button type="submit"
                    class="btn-primary w-full px-4 py-3 rounded-xl text-sm font-semibold">
                تأكيد الحجز
            </button>

            <p class="text-[11px] text-slate-400 text-center leading-relaxed">
                بعد الإرسال يدخل الحجز قائمة المراجعة. هتوصلك التذكرة على واتساب فور موافقة الإدارة.
            </p>
        </form>
    </div>
</section>

<script>
    const ticketPrice = {{ (int) $showTime->ticket_price }};
    const maxTickets  = {{ min(10, $remaining) }};

    let count = 1;

    function buildNameRow(index) {
        return `
            <div class="bg-white/5 border border-white/10 rounded-xl p-4 space-y-2">
                <div class="text-xs text-slate-400">التذكرة #${index + 1}</div>
                <input type="text" name="names[]"
                       placeholder="الاسم بالكامل"
                       value="${oldNames[index] ?? ''}"
                       required
                       class="w-full bg-slate-950/50 border border-white/10 rounded-lg px-3 py-2 text-sm
                              focus:outline-none focus:border-brand-500">
                <input type="tel" name="phones[]"
                       placeholder="رقم الموبايل (مثال: 01XXXXXXXXX)"
                       value="${oldPhones[index] ?? ''}"
                       required
                       class="w-full bg-slate-950/50 border border-white/10 rounded-lg px-3 py-2 text-sm
                              focus:outline-none focus:border-brand-500">
            </div>`;
    }

    function render() {
        const container = document.getElementById('namesContainer');
        container.innerHTML = '';
        for (let i = 0; i < count; i++) {
            container.insertAdjacentHTML('beforeend', buildNameRow(i));
        }
        document.getElementById('ticketsCount').innerText = count;
        document.getElementById('totalPrice').innerText = (count * ticketPrice).toLocaleString();
    }

    function changeCount(delta) {
        const next = count + delta;
        if (next < 1 || next > maxTickets) return;
        count = next;
        render();
    }

    const oldNames  = @json(old('names', [])); // eslint-disable-line
    const oldPhones = @json(old('phones', []));

    if (oldNames.length > 0) count = Math.min(oldNames.length, maxTickets);
    render();
</script>
@endsection
