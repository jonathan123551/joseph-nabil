@extends('layouts.app')

@section('title', 'العروض المتاحة')

@section('content')

    <section class="mb-10">
        <div class="card rounded-3xl px-6 py-10 md:px-10 md:py-14 text-center">
            <p class="text-xs font-semibold tracking-[0.3em] uppercase text-brand-300 mb-3">
                EVENTS • TICKETS
            </p>
            <h1 class="text-3xl md:text-4xl font-extrabold leading-tight mb-3">
                احجز تذكرتك في دقائق
            </h1>
            <p class="text-sm md:text-base text-slate-300 max-w-xl mx-auto leading-relaxed">
                تصفّح العروض المتاحة، اختر الموعد المناسب، واحجز مقعدك بسهولة.
                هتوصلك التذكرة على واتساب فور اعتماد الحجز.
            </p>
        </div>
    </section>

    <section>
        <div class="flex items-center justify-between mb-4">
            <h2 class="text-lg md:text-xl font-semibold">العروض المتاحة</h2>
            @if(! $shows->isEmpty())
                <span class="text-xs px-3 py-1 rounded-full bg-white/5 border border-white/10 text-slate-300">
                    {{ $shows->count() }} عرض
                </span>
            @endif
        </div>

        @if($shows->isEmpty())
            <div class="card rounded-2xl p-6 text-sm text-slate-400 text-center">
                لا توجد عروض متاحة حاليًا. عاود التحقق قريبًا.
            </div>
        @else
            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                @foreach($shows as $show)
                    @php
                        $upcoming = $show->showTimes
                            ->where('is_sold_out', false)
                            ->sortBy(fn($t) => $t->date . ' ' . $t->time)
                            ->take(3);
                    @endphp

                    <article class="card rounded-2xl overflow-hidden flex flex-col
                                    transition hover:-translate-y-0.5 hover:border-brand-500/40 hover:shadow-2xl hover:shadow-brand-500/10">

                        @if($show->poster_path)
                            <div class="relative aspect-[4/3] bg-slate-900">
                                <img src="{{ $show->poster_path }}"
                                     alt="{{ $show->title }}"
                                     class="w-full h-full object-cover">
                                <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 to-transparent"></div>
                            </div>
                        @endif

                        <div class="p-5 flex-1 flex flex-col">
                            <h3 class="text-lg font-bold mb-2">{{ $show->title }}</h3>

                            @if($show->description)
                                <p class="text-sm text-slate-400 leading-relaxed line-clamp-3 mb-4">
                                    {{ $show->description }}
                                </p>
                            @endif

                            @if($upcoming->isNotEmpty())
                                <ul class="space-y-1.5 text-xs text-slate-300 mb-4">
                                    @foreach($upcoming as $time)
                                        <li class="flex items-center justify-between bg-white/5 rounded-lg px-3 py-1.5">
                                            <span>
                                                {{ $time->date->format('d/m/Y') }}
                                                •
                                                {{ \Carbon\Carbon::parse($time->time)->format('g:i A') }}
                                            </span>
                                            <span class="text-brand-300 font-semibold">
                                                {{ $time->ticket_price }} ج
                                            </span>
                                        </li>
                                    @endforeach
                                </ul>
                            @endif

                            <a href="{{ route('shows.show', $show) }}"
                               class="mt-auto btn-primary inline-flex items-center justify-center gap-1
                                      px-4 py-2 rounded-xl text-sm font-semibold">
                                تفاصيل وحجز
                                <svg viewBox="0 0 24 24" class="w-4 h-4 -mr-1" fill="none" stroke="currentColor"
                                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M19 12H5M12 5l-7 7 7 7"/>
                                </svg>
                            </a>
                        </div>
                    </article>
                @endforeach
            </div>
        @endif
    </section>
@endsection
