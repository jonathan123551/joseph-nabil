@extends('layouts.app')

@section('title', $show->title)

@section('content')

    <section class="space-y-8">

        <div class="flex flex-col md:flex-row gap-6 items-start">

            @if($show->poster_path)
                <div class="w-full md:w-72 lg:w-80 shrink-0 overflow-hidden rounded-2xl border border-white/10 bg-slate-900">
                    <img src="{{ $show->poster_path }}"
                         alt="{{ $show->title }}"
                         class="w-full h-full object-cover">
                </div>
            @endif

            <div class="flex-1 min-w-0">
                <a href="{{ route('shows.index') }}"
                   class="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-white mb-3">
                    <svg viewBox="0 0 24 24" class="w-3 h-3" fill="none" stroke="currentColor"
                         stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M5 12h14M12 5l7 7-7 7"/>
                    </svg>
                    رجوع إلى كل العروض
                </a>

                <h1 class="text-2xl md:text-3xl font-bold mb-3">{{ $show->title }}</h1>

                @if($show->description)
                    <p class="text-sm md:text-base text-slate-300 leading-relaxed whitespace-pre-line">
                        {{ $show->description }}
                    </p>
                @endif

                <div class="mt-4 flex flex-wrap gap-2 text-xs text-slate-300">
                    <span class="px-3 py-1 rounded-full bg-white/5 border border-white/10">
                        حجز إلكتروني
                    </span>
                    <span class="px-3 py-1 rounded-full bg-white/5 border border-white/10">
                        تذكرة QR
                    </span>
                </div>
            </div>
        </div>

        <div>
            <h2 class="text-lg font-semibold mb-3">المواعيد المتاحة</h2>

            <div class="space-y-3">
                @forelse($show->showTimes as $time)
                    @php
                        $reserved = \App\Models\Booking::where('show_time_id', $time->id)
                            ->whereIn('status', ['approved', 'pending'])
                            ->sum('tickets_count');
                        $remaining  = max(0, $time->total_tickets - $reserved);
                        $isSoldOut  = $time->is_sold_out || $remaining <= 0;
                        $fewLeft    = ! $isSoldOut && $remaining <= 10;
                    @endphp

                    <div class="card rounded-2xl px-5 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4
                                {{ $isSoldOut ? 'opacity-60' : '' }}">

                        <div class="flex items-start gap-3 min-w-0">
                            <div class="shrink-0 w-12 h-12 rounded-xl flex items-center justify-center
                                        bg-brand-500/10 border border-brand-500/30 text-brand-300">
                                <svg viewBox="0 0 24 24" class="w-5 h-5" fill="none" stroke="currentColor"
                                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <rect x="3" y="4" width="18" height="18" rx="2"/>
                                    <path d="M16 2v4M8 2v4M3 10h18"/>
                                </svg>
                            </div>

                            <div>
                                <div class="font-semibold text-sm md:text-base">
                                    {{ $time->date->format('d/m/Y') }}
                                    <span class="text-slate-400">•</span>
                                    {{ \Carbon\Carbon::parse($time->time)->format('g:i A') }}
                                </div>
                                <div class="text-xs text-slate-400 mt-1 flex items-center gap-2 flex-wrap">
                                    <span>سعر التذكرة:
                                        <span class="text-brand-300 font-semibold">
                                            {{ $time->ticket_price }} جنيه
                                        </span>
                                    </span>

                                    @if($isSoldOut)
                                        <span class="px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-200 border border-rose-500/30">
                                            مكتمل العدد
                                        </span>
                                    @elseif($fewLeft)
                                        <span class="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-200 border border-amber-500/30">
                                            متبقي {{ $remaining }} فقط
                                        </span>
                                    @else
                                        <span class="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-200 border border-emerald-500/30">
                                            متاح
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>

                        <div class="md:text-left">
                            @if($isSoldOut)
                                <span class="inline-flex px-4 py-2 rounded-xl bg-white/5 text-slate-400 text-sm cursor-not-allowed">
                                    غير متاح
                                </span>
                            @else
                                <a href="{{ route('bookings.create', $time) }}"
                                   class="btn-primary inline-flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-semibold">
                                    احجز الآن
                                </a>
                            @endif
                        </div>
                    </div>
                @empty
                    <div class="card rounded-2xl p-6 text-sm text-slate-400 text-center">
                        لا توجد مواعيد متاحة حاليًا لهذا العرض.
                    </div>
                @endforelse
            </div>
        </div>
    </section>
@endsection
