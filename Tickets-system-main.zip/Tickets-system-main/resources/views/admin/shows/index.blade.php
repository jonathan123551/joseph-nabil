@extends('layouts.app')

@section('title', 'العروض')

@section('content')
<section class="space-y-6">

    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
            <h1 class="text-2xl font-bold mb-1">العروض</h1>
            <p class="text-sm text-slate-400">إدارة العروض الإلكترونية ومواعيدها.</p>
        </div>
        <a href="{{ route('admin.shows.create') }}"
           class="btn-primary inline-flex items-center justify-center gap-1 px-4 py-2 rounded-xl text-sm font-semibold">
            <svg viewBox="0 0 24 24" class="w-4 h-4" fill="none" stroke="currentColor"
                 stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 5v14M5 12h14"/>
            </svg>
            إضافة عرض
        </a>
    </div>

    @if(session('status'))
        <div class="bg-emerald-500/10 border border-emerald-500/40 text-emerald-200 text-xs rounded-xl p-3">
            {{ session('status') }}
        </div>
    @endif

    @if($shows->isEmpty())
        <div class="card rounded-2xl p-6 text-center text-sm text-slate-400">
            لا توجد عروض حتى الآن. ابدأ بإنشاء أول عرض.
        </div>
    @else
        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            @foreach($shows as $show)
                <article class="card rounded-2xl overflow-hidden flex flex-col">
                    <div class="aspect-[4/3] bg-slate-900 relative">
                        @if($show->poster_path)
                            <img src="{{ $show->poster_path }}"
                                 alt="{{ $show->title }}"
                                 class="w-full h-full object-cover">
                        @else
                            <div class="w-full h-full flex items-center justify-center text-slate-700">
                                <svg viewBox="0 0 24 24" class="w-12 h-12" fill="none" stroke="currentColor"
                                     stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                                    <rect x="3" y="3" width="18" height="18" rx="2"/>
                                    <circle cx="9" cy="9" r="2"/>
                                    <path d="m21 15-5-5L5 21"/>
                                </svg>
                            </div>
                        @endif

                        <span class="absolute top-3 right-3 text-[11px] px-2 py-1 rounded-full
                                     {{ $show->is_active
                                         ? 'bg-emerald-500/20 text-emerald-200 border border-emerald-500/40'
                                         : 'bg-slate-800/80 text-slate-300 border border-white/10' }}">
                            {{ $show->is_active ? 'فعال' : 'مخفي' }}
                        </span>
                    </div>

                    <div class="p-4 flex-1 flex flex-col">
                        <h3 class="font-semibold mb-1">{{ $show->title }}</h3>
                        <p class="text-xs text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                            {{ $show->description }}
                        </p>

                        <div class="flex items-center justify-between mb-3">
                            <form action="{{ route('admin.shows.toggle', $show) }}" method="POST">
                                @csrf
                                <button type="submit"
                                        class="text-xs px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition">
                                    {{ $show->is_active ? 'إخفاء' : 'تفعيل' }}
                                </button>
                            </form>
                        </div>

                        <div class="mt-auto grid grid-cols-3 gap-2 text-xs">
                            <a href="{{ route('admin.shows.times.index', $show) }}"
                               class="text-center px-2 py-2 rounded-lg bg-violet-500/15 text-violet-200 border border-violet-500/30 hover:bg-violet-500/25 transition">
                                المواعيد
                            </a>
                            <a href="{{ route('admin.shows.edit', $show) }}"
                               class="text-center px-2 py-2 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition">
                                تعديل
                            </a>
                            <form action="{{ route('admin.shows.destroy', $show) }}" method="POST"
                                  onsubmit="return confirm('هل أنت متأكد من حذف هذا العرض؟');">
                                @csrf
                                @method('DELETE')
                                <button type="submit"
                                        class="w-full px-2 py-2 rounded-lg bg-rose-500/15 text-rose-200 border border-rose-500/30 hover:bg-rose-500/25 transition">
                                    حذف
                                </button>
                            </form>
                        </div>
                    </div>
                </article>
            @endforeach
        </div>
    @endif
</section>
@endsection
