@extends('layouts.app')

@section('title', 'مواعيد ' . $show->title)

@section('content')
<section class="space-y-6">

    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
            <a href="{{ route('admin.shows.index') }}"
               class="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-white mb-2">
                <svg viewBox="0 0 24 24" class="w-3 h-3" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
                رجوع لقائمة العروض
            </a>
            <h1 class="text-2xl font-bold mb-1">مواعيد العرض</h1>
            <p class="text-sm text-slate-400">{{ $show->title }}</p>
        </div>

        <a href="{{ route('admin.shows.times.create', $show) }}"
           class="btn-primary inline-flex items-center justify-center gap-1 px-4 py-2 rounded-xl text-sm font-semibold">
            <svg viewBox="0 0 24 24" class="w-4 h-4" fill="none" stroke="currentColor"
                 stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 5v14M5 12h14"/>
            </svg>
            موعد جديد
        </a>
    </div>

    @if(session('status'))
        <div class="bg-emerald-500/10 border border-emerald-500/40 text-emerald-200 text-xs rounded-xl p-3">
            {{ session('status') }}
        </div>
    @endif

    @if($times->isEmpty())
        <div class="card rounded-2xl p-6 text-center text-sm text-slate-400">
            لا توجد مواعيد لهذا العرض حتى الآن.
        </div>
    @else
        <div class="card rounded-2xl overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-slate-200">
                    <thead class="bg-white/5 text-xs text-slate-400 uppercase">
                        <tr>
                            <th class="px-4 py-3 text-right">التاريخ</th>
                            <th class="px-4 py-3 text-right">الساعة</th>
                            <th class="px-4 py-3 text-right">السعر</th>
                            <th class="px-4 py-3 text-center">المتاح / الإجمالي</th>
                            <th class="px-4 py-3 text-center">الحالة</th>
                            <th class="px-4 py-3 text-left">إجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($times as $time)
                            @php
                                $reserved = $time->bookings()
                                    ->whereIn('status', ['approved', 'pending'])
                                    ->sum('tickets_count');
                                $remaining = max(0, $time->total_tickets - $reserved);
                                $isLocked  = $remaining <= 0;
                            @endphp

                            <tr class="border-t border-white/5 hover:bg-white/5">
                                <td class="px-4 py-3 whitespace-nowrap">
                                    {{ $time->date->format('d/m/Y') }}
                                </td>
                                <td class="px-4 py-3 whitespace-nowrap">
                                    {{ \Carbon\Carbon::parse($time->time)->format('g:i A') }}
                                </td>
                                <td class="px-4 py-3 text-brand-300">
                                    {{ $time->ticket_price }} ج
                                </td>
                                <td class="px-4 py-3 text-center">
                                    {{ $remaining }} / {{ $time->total_tickets }}
                                </td>
                                <td class="px-4 py-3 text-center">
                                    <form action="{{ route('admin.shows.times.toggle', [$show, $time]) }}" method="POST" class="inline-flex">
                                        @csrf
                                        @method('PATCH')
                                        <button type="submit"
                                                @if($isLocked) disabled @endif
                                                class="text-[11px] px-3 py-1 rounded-full transition
                                                {{ ($time->is_sold_out || $isLocked)
                                                    ? 'bg-rose-500/15 text-rose-200 border border-rose-500/30'
                                                    : 'bg-emerald-500/15 text-emerald-200 border border-emerald-500/30 hover:bg-emerald-500/25' }}
                                                {{ $isLocked ? 'opacity-60 cursor-not-allowed' : '' }}">
                                            {{ ($time->is_sold_out || $isLocked) ? 'مكتمل' : 'متاح' }}
                                        </button>
                                    </form>
                                </td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center justify-end gap-2 text-xs">
                                        <a href="{{ route('admin.shows.times.edit', [$show, $time]) }}"
                                           class="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition">
                                            تعديل
                                        </a>
                                        <form action="{{ route('admin.shows.times.destroy', [$show, $time]) }}"
                                              method="POST"
                                              onsubmit="return confirm('متأكد من حذف هذا الموعد؟');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit"
                                                    class="px-3 py-1.5 rounded-lg bg-rose-500/15 text-rose-200 border border-rose-500/30 hover:bg-rose-500/25 transition">
                                                حذف
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    @endif
</section>
@endsection
