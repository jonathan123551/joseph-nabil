@extends('layouts.app')

@section('title', 'تعديل موعد - ' . $show->title)

@section('content')
<section class="max-w-2xl mx-auto space-y-6">

    <div>
        <a href="{{ route('admin.shows.times.index', $show) }}"
           class="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-white mb-2">
            <svg viewBox="0 0 24 24" class="w-3 h-3" fill="none" stroke="currentColor"
                 stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
            رجوع للمواعيد
        </a>
        <h1 class="text-2xl font-bold mb-1">تعديل موعد</h1>
        <p class="text-sm text-slate-400">{{ $show->title }}</p>
    </div>

    @if ($errors->any())
        <div class="bg-rose-500/10 border border-rose-500/40 text-rose-200 text-xs rounded-xl p-3">
            <ul class="space-y-1">
                @foreach($errors->all() as $error)
                    <li>• {{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.shows.times.update', [$show, $showTime]) }}" method="POST"
          class="card rounded-2xl p-5 md:p-6 space-y-4">
        @csrf
        @method('PUT')

        <div class="grid md:grid-cols-2 gap-4">
            <div>
                <label class="block text-xs mb-1 text-slate-300">التاريخ</label>
                <input type="date" name="date"
                       value="{{ old('date', $showTime->date->format('Y-m-d')) }}" required
                       class="w-full rounded-xl bg-slate-950/50 border border-white/10 px-3 py-2 text-sm focus:outline-none focus:border-brand-500">
            </div>
            <div>
                <label class="block text-xs mb-1 text-slate-300">الساعة</label>
                <input type="time" name="time"
                       value="{{ old('time', $showTime->time) }}" required
                       class="w-full rounded-xl bg-slate-950/50 border border-white/10 px-3 py-2 text-sm focus:outline-none focus:border-brand-500">
            </div>
        </div>

        <div class="grid md:grid-cols-2 gap-4">
            <div>
                <label class="block text-xs mb-1 text-slate-300">سعر التذكرة (جنيه)</label>
                <input type="number" step="0.5" min="0" name="ticket_price"
                       value="{{ old('ticket_price', $showTime->ticket_price) }}" required
                       class="w-full rounded-xl bg-slate-950/50 border border-white/10 px-3 py-2 text-sm focus:outline-none focus:border-brand-500">
            </div>
            <div>
                <label class="block text-xs mb-1 text-slate-300">إجمالي التذاكر</label>
                <input type="number" min="1" name="total_tickets"
                       value="{{ old('total_tickets', $showTime->total_tickets) }}" required
                       class="w-full rounded-xl bg-slate-950/50 border border-white/10 px-3 py-2 text-sm focus:outline-none focus:border-brand-500">
            </div>
        </div>

        <label class="flex items-center justify-between bg-white/5 border border-white/10 rounded-xl px-4 py-3">
            <span class="text-sm text-slate-200">تحديد الموعد كمكتمل (Sold Out)</span>
            <input type="checkbox" name="is_sold_out" value="1" class="accent-brand-500"
                   {{ $showTime->is_sold_out ? 'checked' : '' }}>
        </label>

        <div class="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-3">
            <a href="{{ route('admin.shows.times.index', $show) }}"
               class="text-sm px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-center hover:bg-white/10 transition">
                إلغاء
            </a>
            <button type="submit"
                    class="btn-primary px-5 py-2 rounded-xl text-sm font-semibold">
                حفظ التعديلات
            </button>
        </div>
    </form>
</section>
@endsection
