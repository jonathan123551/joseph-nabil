@extends('layouts.app')

@section('title', 'قارئ التذاكر')

@section('content')
<section class="max-w-md mx-auto space-y-4 pb-10">

    <div>
        <a href="{{ route('admin.dashboard') }}"
           class="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-white mb-2">
            <svg viewBox="0 0 24 24" class="w-3 h-3" fill="none" stroke="currentColor"
                 stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
            رجوع للوحة التحكم
        </a>
        <h1 class="text-xl font-bold">قارئ التذاكر</h1>
        <p class="text-xs text-slate-400 mt-1">امسح كود QR للتحقق من التذكرة عند الدخول.</p>
    </div>

    {{-- Result card --}}
    <div id="card"
         class="hidden card rounded-2xl p-3 text-sm space-y-2"></div>

    {{-- Scanner --}}
    <div class="relative card rounded-3xl p-3 overflow-hidden bg-slate-950/80">
        <div id="qr-reader" class="rounded-2xl overflow-hidden border border-white/10"></div>

        <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div class="scan-frame"></div>
        </div>

        <div class="scan-line"></div>

        <div id="status"
             class="absolute top-5 left-1/2 -translate-x-1/2 z-50
                    px-4 py-2 rounded-full
                    bg-slate-950/80 backdrop-blur
                    text-sm text-white
                    shadow-lg border border-white/10
                    transition-all duration-300">
            جاهز للفحص
        </div>
    </div>

    <div class="flex gap-2">
        <button id="flashBtn"
                class="flex-1 text-xs py-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition">
            الإضاءة
        </button>

        <button onclick="location.reload()"
                class="flex-1 text-xs py-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition">
            إعادة تشغيل
        </button>
    </div>
</section>

<div id="flash" class="fixed inset-0 flex items-center justify-center hidden z-50">
    <div id="flashIcon" class="text-8xl font-black"></div>
</div>

<script src="https://unpkg.com/html5-qrcode"></script>

<style>
.scan-frame{
    width:230px;
    height:230px;
    border:2px solid rgba(255,255,255,0.2);
    border-radius:20px;
    box-shadow:0 0 30px rgba(99,102,241,0.25);
}

.scan-line{
    position:absolute;
    left:10%;
    right:10%;
    height:2px;
    background:linear-gradient(90deg,transparent,#6366f1,transparent);
    animation:scan 1.2s infinite;
}
@keyframes scan{
    0%{top:10%}
    50%{top:85%}
    100%{top:10%}
}

.flash-ok{ color:#22c55e; text-shadow:0 0 50px #22c55e; }
.flash-used{ color:#facc15; text-shadow:0 0 50px #facc15; }
.flash-error{ color:#ef4444; text-shadow:0 0 50px #ef4444; }
</style>

<script>
const qr = new Html5Qrcode("qr-reader");

let busy = false;
let lastCode = null;
let lastScanTime = 0;

const COOLDOWN = 3000;

let audioCtx;
function beep(type){
    try{
        if(!audioCtx){
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        }

        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();

        osc.connect(gain);
        gain.connect(audioCtx.destination);

        osc.frequency.value =
            type === 'ok' ? 950 :
            type === 'used' ? 500 : 250;

        gain.gain.value = 0.25;

        osc.start();
        setTimeout(()=>osc.stop(),150);
    }catch(e){}
}

function vibrate(type){
    if(type==='ok') navigator.vibrate?.(120);
    else if(type==='used') navigator.vibrate?.([100,50,100]);
    else navigator.vibrate?.(200);
}

function flash(type){
    const f = document.getElementById('flash');
    const i = document.getElementById('flashIcon');

    f.classList.remove('hidden');

    if(type==='ok'){ i.textContent='✓'; i.className='flash-ok'; }
    if(type==='used'){ i.textContent='!'; i.className='flash-used'; }
    if(type==='error'){ i.textContent='✕'; i.className='flash-error'; }

    setTimeout(()=>f.classList.add('hidden'),700);
}

function setStatus(text,type){
    const s = document.getElementById('status');

    s.innerText = text;
    s.className = "absolute top-5 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full text-sm border transition-all duration-300";

    if(type==='ok'){
        s.classList.add('bg-emerald-500/90','text-white','border-emerald-300');
    }
    else if(type==='used'){
        s.classList.add('bg-amber-400/90','text-slate-900','border-amber-200');
    }
    else{
        s.classList.add('bg-rose-500/90','text-white','border-rose-300');
    }

    s.style.transform = "translate(-50%, -5px) scale(1.1)";
    setTimeout(()=>{
        s.style.transform = "translate(-50%, 0) scale(1)";
    },150);
}

function render(d){
    const c = document.getElementById('card');
    c.classList.remove('hidden');

    c.innerHTML = `
        <div class="space-y-2 p-2">
            <div class="text-white font-semibold text-sm">${d.name}</div>
            <div class="border-t border-white/10"></div>
            <div class="text-slate-300 text-xs">${d.show_title}</div>
            <div class="text-xs font-medium text-brand-300">${d.date} • ${d.time}</div>
            ${
                d.scanned_at
                ? `<div class="text-emerald-400 text-xs font-semibold">دخل في: ${d.scanned_at}</div>`
                : ''
            }
        </div>
    `;
}

function check(code){
    fetch('/admin/scanner/check',{
        method:'POST',
        headers:{
            'Content-Type':'application/json',
            'X-CSRF-TOKEN':'{{ csrf_token() }}'
        },
        body:JSON.stringify({code})
    })
    .then(r=>r.json())
    .then(d=>{
        if(d.status==='ok'){
            setStatus('دخول مسموح','ok');
            vibrate('ok');
            beep('ok');
            flash('ok');
            render(d);
        }
        else if(d.status==='used'){
            setStatus('تذكرة مستخدمة','used');
            vibrate('used');
            beep('used');
            flash('used');
            render(d);
        }
        else{
            setStatus('غير صالحة','error');
            vibrate('error');
            beep('error');
            flash('error');
        }
    })
    .finally(()=>{
        setTimeout(()=>busy=false,800);
    });
}

qr.start(
    { facingMode: "environment" },
    {
        fps: 12,
        qrbox: 260
    },
    text=>{
        const now = Date.now();

        if(text === lastCode && now - lastScanTime < COOLDOWN){
            return;
        }

        if(busy) return;

        busy = true;
        lastCode = text;
        lastScanTime = now;

        check(text);
    }
);

let flashOn = false;
document.getElementById('flashBtn').onclick = async () => {
    try{
        flashOn = !flashOn;
        await qr.applyVideoConstraints({
            advanced: [{ torch: flashOn }]
        });
    }catch(e){
        alert('الفلاش غير مدعوم');
    }
};
</script>
@endsection
