@extends('layouts.app')

@section('title', 'لوحة التحكم')

@section('content')
<section class="space-y-8">

    <div>
        <h1 class="text-2xl font-bold mb-1">لوحة التحكم</h1>
        <p class="text-sm text-slate-400">نظرة عامة على العروض، المواعيد والحجوزات.</p>
    </div>

    @if(session('status'))
        <div class="bg-emerald-500/10 border border-emerald-500/40 text-emerald-200 text-xs rounded-xl p-3">
            {{ session('status') }}
        </div>
    @endif

    {{-- Stats grid --}}
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">

        @php
            $cards = [
                ['label' => 'العروض',           'value' => $totalShows,           'tone' => 'brand'],
                ['label' => 'المواعيد',         'value' => $totalShowTimes,       'tone' => 'violet'],
                ['label' => 'تذاكر متاحة',      'value' => $ticketsRemaining,     'tone' => 'sky'],
                ['label' => 'تذاكر معتمدة',     'value' => $totalTicketsApproved, 'tone' => 'emerald'],
                ['label' => 'حجوزات معلّقة',    'value' => $pendingBookings,      'tone' => 'amber'],
                ['label' => 'حجوزات مرفوضة',    'value' => $rejectedBookings,     'tone' => 'rose'],
            ];

            $tones = [
                'brand'   => 'text-brand-300 border-brand-500/30 bg-brand-500/10',
                'violet'  => 'text-violet-300 border-violet-500/30 bg-violet-500/10',
                'sky'     => 'text-sky-300 border-sky-500/30 bg-sky-500/10',
                'emerald' => 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10',
                'amber'   => 'text-amber-300 border-amber-500/30 bg-amber-500/10',
                'rose'    => 'text-rose-300 border-rose-500/30 bg-rose-500/10',
            ];
        @endphp

        @foreach($cards as $card)
            <div class="card rounded-2xl p-4">
                <div class="text-xs text-slate-400 mb-1">{{ $card['label'] }}</div>
                <div class="text-2xl font-bold {{ explode(' ', $tones[$card['tone']])[0] }}">
                    {{ $card['value'] }}
                </div>
            </div>
        @endforeach
    </div>

    {{-- Quick actions --}}
    <div class="grid md:grid-cols-3 gap-4">
        <a href="{{ route('admin.shows.index') }}"
           class="card rounded-2xl p-5 flex items-start gap-4 transition hover:-translate-y-0.5 hover:border-brand-500/40">
            <div class="w-11 h-11 rounded-xl bg-brand-500/15 border border-brand-500/30 text-brand-300 flex items-center justify-center shrink-0">
                <svg viewBox="0 0 24 24" class="w-5 h-5" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="3" width="18" height="18" rx="2"/>
                    <path d="M3 9h18M9 21V9"/>
                </svg>
            </div>
            <div>
                <h3 class="font-semibold mb-1">إدارة العروض</h3>
                <p class="text-xs text-slate-400 leading-relaxed">
                    إنشاء وتعديل العروض، رفع البوسترات، وإدارة المواعيد.
                </p>
            </div>
        </a>

        <a href="{{ route('admin.bookings.index') }}"
           class="card rounded-2xl p-5 flex items-start gap-4 transition hover:-translate-y-0.5 hover:border-brand-500/40">
            <div class="w-11 h-11 rounded-xl bg-violet-500/15 border border-violet-500/30 text-violet-300 flex items-center justify-center shrink-0">
                <svg viewBox="0 0 24 24" class="w-5 h-5" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M2 7h20M2 12h20M2 17h20"/>
                </svg>
            </div>
            <div>
                <h3 class="font-semibold mb-1">الحجوزات</h3>
                <p class="text-xs text-slate-400 leading-relaxed">
                    مراجعة الحجوزات، الموافقة أو الرفض، وإعادة إرسال التذاكر.
                </p>
            </div>
        </a>

        <a href="{{ route('admin.scanner') }}"
           class="card rounded-2xl p-5 flex items-start gap-4 transition hover:-translate-y-0.5 hover:border-brand-500/40">
            <div class="w-11 h-11 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 flex items-center justify-center shrink-0">
                <svg viewBox="0 0 24 24" class="w-5 h-5" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="3" width="7" height="7"/>
                    <rect x="14" y="3" width="7" height="7"/>
                    <rect x="3" y="14" width="7" height="7"/>
                    <path d="M14 14h3M14 21h3M21 14v3M21 17v4"/>
                </svg>
            </div>
            <div>
                <h3 class="font-semibold mb-1">قارئ التذاكر</h3>
                <p class="text-xs text-slate-400 leading-relaxed">
                    افتح القارئ على باب القاعة لمسح أكواد QR والتحقق من التذاكر.
                </p>
            </div>
        </a>
    </div>

    {{-- Show times stats --}}
    <section class="space-y-3">
        <h2 class="text-base font-semibold">المواعيد والتذاكر</h2>

        <div class="card rounded-2xl overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-slate-200">
                    <thead class="bg-white/5 text-xs text-slate-400 uppercase">
                        <tr>
                            <th class="px-4 py-3 text-right">العرض</th>
                            <th class="px-4 py-3 text-right">التاريخ</th>
                            <th class="px-4 py-3 text-right">الساعة</th>
                            <th class="px-4 py-3 text-center">الإجمالي</th>
                            <th class="px-4 py-3 text-center text-emerald-300">معتمد</th>
                            <th class="px-4 py-3 text-center text-amber-300">معلّق</th>
                            <th class="px-4 py-3 text-center text-sky-300">المتبقي</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($showTimesStats as $time)
                            <tr class="border-t border-white/5 hover:bg-white/5">
                                <td class="px-4 py-3">{{ $time->show->title }}</td>
                                <td class="px-4 py-3 whitespace-nowrap">
                                    {{ $time->date?->format('Y-m-d') }}
                                </td>
                                <td class="px-4 py-3 whitespace-nowrap">
                                    {{ \Carbon\Carbon::parse($time->time)->format('g:i A') }}
                                </td>
                                <td class="px-4 py-3 text-center">{{ $time->total_tickets }}</td>
                                <td class="px-4 py-3 text-center text-emerald-300">{{ $time->approved_tickets }}</td>
                                <td class="px-4 py-3 text-center text-amber-300">{{ $time->pending_tickets }}</td>
                                <td class="px-4 py-3 text-center
                                    {{ $time->remaining_tickets > 0 ? 'text-sky-300' : 'text-rose-300' }}">
                                    {{ $time->remaining_tickets }}
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="px-4 py-6 text-center text-slate-400 text-sm">
                                    لا توجد مواعيد بعد.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</section>
@endsection
