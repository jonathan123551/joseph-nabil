@extends('layouts.app')

@section('title', 'الحجوزات')

@section('content')
<section class="space-y-6">

    <div>
        <h1 class="text-2xl font-bold mb-1">الحجوزات</h1>
        <p class="text-sm text-slate-400">مراجعة الحجوزات واعتمادها أو رفضها.</p>
    </div>

    @if(session('status'))
        <div class="bg-emerald-500/10 border border-emerald-500/40 text-emerald-200 text-xs rounded-xl p-3">
            {{ session('status') }}
        </div>
    @endif

    {{-- Filters --}}
    <div class="card rounded-2xl p-4">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
            <input id="searchInput" type="text"
                   placeholder="بحث بالاسم أو الموبايل أو رقم الحجز"
                   class="rounded-xl bg-slate-950/50 border border-white/10 px-3 py-2 focus:outline-none focus:border-brand-500">

            <select id="statusFilter"
                    class="rounded-xl bg-slate-950/50 border border-white/10 px-3 py-2 focus:outline-none focus:border-brand-500">
                <option value="">كل الحالات</option>
                <option value="pending">معلّق</option>
                <option value="approved">معتمد</option>
                <option value="rejected">مرفوض</option>
            </select>

            <select id="dateTimeFilter"
                    class="rounded-xl bg-slate-950/50 border border-white/10 px-3 py-2 focus:outline-none focus:border-brand-500">
                <option value="">كل المواعيد</option>
                @foreach(
                    $bookings->map(fn($b) => $b->showTime
                        ? $b->showTime->date->format('Y-m-d') . ' ' . $b->showTime->time
                        : null)->filter()->unique()->sort()
                    as $dt
                )
                    <option value="{{ $dt }}">
                        {{ \Carbon\Carbon::parse($dt)->format('d/m/Y • g:i A') }}
                    </option>
                @endforeach
            </select>
        </div>
    </div>

    @if($bookings->isEmpty())
        <div class="card rounded-2xl p-6 text-center text-sm text-slate-400">
            لا توجد حجوزات بعد.
        </div>
    @else
        {{-- Desktop Table --}}
        <div class="hidden md:block card rounded-2xl overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-slate-200">
                    <thead class="bg-white/5 text-xs text-slate-400 uppercase">
                        <tr>
                            <th class="px-4 py-3 text-right">الكود</th>
                            <th class="px-4 py-3 text-right">الضيف</th>
                            <th class="px-4 py-3 text-right">العرض / الموعد</th>
                            <th class="px-4 py-3 text-center">عدد التذاكر</th>
                            <th class="px-4 py-3 text-center">الحالة</th>
                            <th class="px-4 py-3 text-center">الإرسال</th>
                            <th class="px-4 py-3 text-left">إجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($bookings as $booking)
                            @php
                                $dt = $booking->showTime
                                    ? $booking->showTime->date->format('Y-m-d') . ' ' . $booking->showTime->time
                                    : '';
                                $allSent = $booking->tickets->every(fn($t) => $t->whatsapp_sent);
                                $total   = $booking->tickets->count();
                                $sent    = $booking->tickets->where('whatsapp_sent', true)->count();
                            @endphp

                            <tr class="border-t border-white/5 hover:bg-white/5 booking-row"
                                data-search="{{ strtolower($booking->full_name . ' ' . $booking->phone . ' ' . $booking->reference_code) }}"
                                data-status="{{ $booking->status }}"
                                data-datetime="{{ $dt }}">

                                <td class="px-4 py-3 font-mono text-xs text-slate-400">
                                    {{ $booking->reference_code }}
                                </td>

                                <td class="px-4 py-3">
                                    <div class="font-medium">{{ $booking->full_name }}</div>
                                    <div class="text-xs text-slate-400">{{ $booking->phone }}</div>
                                </td>

                                <td class="px-4 py-3">
                                    <div>{{ $booking->showTime->show->title ?? '-' }}</div>
                                    <div class="text-xs text-slate-400">
                                        {{ $booking->showTime?->date->format('d/m/Y') }}
                                        • {{ \Carbon\Carbon::parse($booking->showTime?->time)->format('g:i A') }}
                                    </div>
                                </td>

                                <td class="px-4 py-3 text-center font-semibold">
                                    {{ $booking->tickets_count }}
                                </td>

                                <td class="px-4 py-3 text-center">
                                    <span class="inline-block px-2 py-1 rounded-full text-[11px]
                                        {{ $booking->status === 'approved'
                                            ? 'bg-emerald-500/15 text-emerald-200 border border-emerald-500/30'
                                            : ($booking->status === 'rejected'
                                                ? 'bg-rose-500/15 text-rose-200 border border-rose-500/30'
                                                : 'bg-amber-500/15 text-amber-200 border border-amber-500/30') }}">
                                        @if($booking->status === 'approved') معتمد
                                        @elseif($booking->status === 'rejected') مرفوض
                                        @else معلّق @endif
                                    </span>
                                </td>

                                <td class="px-4 py-3 text-center">
                                    <div class="inline-flex items-center gap-1.5 text-xs text-slate-300">
                                        <span class="w-2 h-2 rounded-full
                                                     {{ $allSent ? 'bg-emerald-400' : 'bg-rose-400' }}"></span>
                                        {{ $sent }}/{{ $total }}
                                    </div>
                                </td>

                                <td class="px-4 py-3 text-left">
                                    <a href="{{ route('admin.bookings.show', $booking) }}"
                                       class="text-xs px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition">
                                        تفاصيل
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        {{-- Mobile Cards --}}
        <div class="md:hidden space-y-3">
            @foreach($bookings as $booking)
                @php
                    $dt = $booking->showTime
                        ? $booking->showTime->date->format('Y-m-d') . ' ' . $booking->showTime->time
                        : '';
                    $allSent = $booking->tickets->every(fn($t) => $t->whatsapp_sent);
                    $total   = $booking->tickets->count();
                    $sent    = $booking->tickets->where('whatsapp_sent', true)->count();
                @endphp

                <div class="card rounded-2xl p-4 booking-card"
                     data-search="{{ strtolower($booking->full_name . ' ' . $booking->phone . ' ' . $booking->reference_code) }}"
                     data-status="{{ $booking->status }}"
                     data-datetime="{{ $dt }}">

                    <div class="flex justify-between items-start mb-3 gap-3">
                        <div class="min-w-0">
                            <div class="font-semibold">{{ $booking->full_name }}</div>
                            <div class="text-xs text-slate-400">{{ $booking->phone }}</div>
                        </div>
                        <span class="font-mono text-[11px] bg-white/5 border border-white/10 rounded-lg px-2 py-1 shrink-0">
                            {{ $booking->reference_code }}
                        </span>
                    </div>

                    <div class="text-xs text-slate-300 mb-3">
                        <div>{{ $booking->showTime->show->title ?? '-' }}</div>
                        <div class="text-slate-400">
                            {{ $booking->showTime?->date->format('d/m/Y') }}
                            • {{ \Carbon\Carbon::parse($booking->showTime?->time)->format('g:i A') }}
                        </div>
                    </div>

                    <div class="flex items-center justify-between gap-2">
                        <div class="flex items-center gap-2">
                            <span class="px-2 py-1 rounded-full text-[11px]
                                {{ $booking->status === 'approved'
                                    ? 'bg-emerald-500/15 text-emerald-200 border border-emerald-500/30'
                                    : ($booking->status === 'rejected'
                                        ? 'bg-rose-500/15 text-rose-200 border border-rose-500/30'
                                        : 'bg-amber-500/15 text-amber-200 border border-amber-500/30') }}">
                                @if($booking->status === 'approved') معتمد
                                @elseif($booking->status === 'rejected') مرفوض
                                @else معلّق @endif
                            </span>
                            <span class="inline-flex items-center gap-1.5 text-[11px] text-slate-300">
                                <span class="w-2 h-2 rounded-full {{ $allSent ? 'bg-emerald-400' : 'bg-rose-400' }}"></span>
                                {{ $sent }}/{{ $total }}
                            </span>
                        </div>

                        <a href="{{ route('admin.bookings.show', $booking) }}"
                           class="text-xs px-3 py-1.5 rounded-lg bg-white/5 border border-white/10">
                            تفاصيل
                        </a>
                    </div>
                </div>
            @endforeach
        </div>
    @endif
</section>

<script>
    const searchInput   = document.getElementById('searchInput');
    const statusFilter  = document.getElementById('statusFilter');
    const dateFilter    = document.getElementById('dateTimeFilter');

    function applyFilters() {
        const q       = (searchInput.value || '').trim().toLowerCase();
        const status  = statusFilter.value;
        const dt      = dateFilter.value;

        document.querySelectorAll('.booking-row, .booking-card').forEach(el => {
            const matchSearch = !q || el.dataset.search.includes(q);
            const matchStatus = !status || el.dataset.status === status;
            const matchDate   = !dt || el.dataset.datetime === dt;
            el.style.display = (matchSearch && matchStatus && matchDate) ? '' : 'none';
        });
    }

    [searchInput, statusFilter, dateFilter].forEach(el => {
        if (el) el.addEventListener('input', applyFilters);
    });
</script>
@endsection
