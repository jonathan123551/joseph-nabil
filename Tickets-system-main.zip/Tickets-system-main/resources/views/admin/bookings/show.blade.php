@extends('layouts.app')

@section('title', 'تفاصيل الحجز #' . $booking->id)

@section('content')
<section class="max-w-4xl mx-auto space-y-6">

    @if(session('status'))
        <div class="bg-emerald-500/10 border border-emerald-500/40 text-emerald-200 text-xs rounded-xl p-3 text-center">
            {{ session('status') }}
        </div>
    @endif

    <div class="flex justify-between items-center gap-3">
        <div>
            <a href="{{ route('admin.bookings.index') }}"
               class="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-white mb-2">
                <svg viewBox="0 0 24 24" class="w-3 h-3" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
                رجوع للحجوزات
            </a>
            <h1 class="text-xl font-bold">تفاصيل الحجز #{{ $booking->id }}</h1>
        </div>

        <span class="px-3 py-1.5 rounded-full text-xs font-semibold
            {{ $booking->status === 'approved'
                ? 'bg-emerald-500/15 text-emerald-200 border border-emerald-500/30'
                : ($booking->status === 'rejected'
                    ? 'bg-rose-500/15 text-rose-200 border border-rose-500/30'
                    : 'bg-amber-500/15 text-amber-200 border border-amber-500/30') }}">
            @if($booking->status === 'approved') معتمد
            @elseif($booking->status === 'rejected') مرفوض
            @else معلّق @endif
        </span>
    </div>

    <div class="grid sm:grid-cols-2 gap-4">

        <div class="card rounded-2xl p-5 space-y-3">
            <h2 class="text-sm font-semibold text-slate-300">معلومات الحجز</h2>
            <dl class="text-sm space-y-2">
                <div class="flex justify-between">
                    <dt class="text-slate-400">الكود</dt>
                    <dd class="font-mono text-brand-300">{{ $booking->reference_code }}</dd>
                </div>
                <div class="flex justify-between">
                    <dt class="text-slate-400">الحاجز</dt>
                    <dd>{{ $booking->full_name }}</dd>
                </div>
                <div class="flex justify-between">
                    <dt class="text-slate-400">رقم الموبايل</dt>
                    <dd>{{ $booking->phone }}</dd>
                </div>
                <div class="flex justify-between">
                    <dt class="text-slate-400">عدد التذاكر</dt>
                    <dd class="font-semibold">{{ $booking->tickets_count }}</dd>
                </div>
                <div class="flex justify-between">
                    <dt class="text-slate-400">الإجمالي</dt>
                    <dd class="text-brand-300 font-semibold">
                        {{ number_format($booking->total_price, 0) }} جنيه
                    </dd>
                </div>
            </dl>
        </div>

        <div class="card rounded-2xl p-5 space-y-3">
            <h2 class="text-sm font-semibold text-slate-300">العرض والموعد</h2>
            <dl class="text-sm space-y-2">
                <div class="flex justify-between">
                    <dt class="text-slate-400">العرض</dt>
                    <dd>{{ $booking->showTime->show->title ?? '-' }}</dd>
                </div>
                <div class="flex justify-between">
                    <dt class="text-slate-400">التاريخ</dt>
                    <dd>{{ $booking->showTime?->date->format('d/m/Y') }}</dd>
                </div>
                <div class="flex justify-between">
                    <dt class="text-slate-400">الساعة</dt>
                    <dd>{{ \Carbon\Carbon::parse($booking->showTime?->time)->format('g:i A') }}</dd>
                </div>
            </dl>
        </div>
    </div>

    <div class="card rounded-2xl p-5">
        <h2 class="text-sm font-semibold text-slate-300 mb-4">التذاكر ({{ $booking->tickets->count() }})</h2>

        <div class="space-y-2">
            @foreach($booking->tickets as $ticket)
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3
                            bg-slate-950/40 border border-white/5 rounded-xl p-3">
                    <div class="min-w-0">
                        <div class="font-medium">{{ $ticket->name }}</div>
                        <div class="text-xs text-slate-400">{{ $ticket->phone }}</div>
                        @if($ticket->ticket_code)
                            <div class="text-[10px] font-mono text-slate-500 mt-1">
                                {{ $ticket->ticket_code }}
                            </div>
                        @endif
                    </div>

                    <div class="flex items-center gap-2">
                        <span class="inline-flex items-center gap-1.5 text-[11px] px-2 py-1 rounded-full
                            {{ $ticket->whatsapp_sent
                                ? 'bg-emerald-500/15 text-emerald-200 border border-emerald-500/30'
                                : 'bg-rose-500/15 text-rose-200 border border-rose-500/30' }}">
                            <span class="w-1.5 h-1.5 rounded-full
                                         {{ $ticket->whatsapp_sent ? 'bg-emerald-400' : 'bg-rose-400' }}"></span>
                            {{ $ticket->whatsapp_sent ? 'تم الإرسال' : 'لم يُرسل' }}
                        </span>

                        @if($booking->status === 'approved')
                            @if($ticket->qr_image_path)
                                <a href="{{ $ticket->qr_image_path }}" target="_blank"
                                   class="text-[11px] px-2 py-1 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition">
                                    عرض
                                </a>
                            @endif

                            <form action="{{ route('admin.resend.ticket', $ticket->id) }}" method="POST">
                                @csrf
                                <button class="text-[11px] px-2 py-1 rounded-full bg-brand-500/15 text-brand-200 border border-brand-500/30 hover:bg-brand-500/25 transition">
                                    إعادة إرسال
                                </button>
                            </form>
                        @endif
                    </div>
                </div>
            @endforeach
        </div>
    </div>

    @if($booking->status === 'pending')
        <div class="flex flex-col sm:flex-row gap-3 justify-center">
            <form action="{{ route('admin.bookings.approve', $booking) }}" method="POST" class="flex-1 sm:flex-none">
                @csrf
                <button class="w-full px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-sm font-semibold transition">
                    اعتماد الحجز
                </button>
            </form>

            <form action="{{ route('admin.bookings.reject', $booking) }}" method="POST" class="flex-1 sm:flex-none">
                @csrf
                <button class="w-full px-5 py-2.5 rounded-xl bg-rose-500/90 hover:bg-rose-500 text-white text-sm font-semibold transition">
                    رفض الحجز
                </button>
            </form>
        </div>
    @endif

    @if($booking->status === 'approved')
        <div class="text-center pt-2">
            <form action="{{ route('admin.booking.delete', $booking->id) }}" method="POST"
                  onsubmit="return confirm('متأكد عايز تمسح الحجز بكل التذاكر؟');">
                @csrf
                @method('DELETE')
                <button class="px-5 py-2 rounded-xl bg-rose-500/15 text-rose-200 border border-rose-500/30 text-sm hover:bg-rose-500/25 transition">
                    حذف الحجز بالكامل
                </button>
            </form>
        </div>
    @endif
</section>
@endsection
