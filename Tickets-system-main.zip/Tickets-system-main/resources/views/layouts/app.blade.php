<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', config('app.name', 'Tickets'))</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&display=swap"
          rel="stylesheet">

    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Cairo', 'Inter', 'system-ui', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            50:  '#eef2ff',
                            100: '#e0e7ff',
                            300: '#a5b4fc',
                            400: '#818cf8',
                            500: '#6366f1',
                            600: '#4f46e5',
                            700: '#4338ca',
                        },
                    },
                },
            },
        };
    </script>

    <style>
        body {
            font-family: 'Cairo', 'Inter', system-ui, sans-serif;
            background:
                radial-gradient(circle at 0% 0%, rgba(99,102,241,0.18), transparent 45%),
                radial-gradient(circle at 100% 0%, rgba(139,92,246,0.16), transparent 45%),
                #0f172a;
            min-height: 100vh;
        }

        .card {
            background: rgba(15, 23, 42, 0.65);
            border: 1px solid rgba(148, 163, 184, 0.12);
            backdrop-filter: blur(8px);
        }

        .btn-primary {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: white;
            transition: all .2s ease;
        }
        .btn-primary:hover { filter: brightness(1.1); transform: translateY(-1px); }

        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
    </style>
</head>
<body class="text-slate-100 min-h-screen flex flex-col">

    {{-- Top navigation --}}
    <header class="sticky top-0 z-40 border-b border-white/5 bg-slate-950/70 backdrop-blur">
        <div class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-4">

            <a href="{{ route('home') }}" class="flex items-center gap-2 group">
                <span class="inline-flex w-9 h-9 rounded-xl items-center justify-center
                             bg-gradient-to-br from-brand-500 to-violet-500 shadow-lg shadow-brand-500/30">
                    <svg viewBox="0 0 24 24" class="w-5 h-5 text-white" fill="none" stroke="currentColor"
                         stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M2 9.5a2.5 2.5 0 0 1 0 5V18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-3.5a2.5 2.5 0 0 1 0-5V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v3.5z"/>
                        <path d="M9 4v16"/>
                    </svg>
                </span>
                <span class="font-bold tracking-tight text-base">
                    {{ config('app.name', 'Tickets') }}
                </span>
            </a>

            <nav class="flex items-center gap-1 text-sm">
                <a href="{{ route('shows.index') }}"
                   class="px-3 py-1.5 rounded-full transition
                          {{ request()->routeIs('shows.*') || request()->routeIs('home')
                              ? 'bg-brand-500/15 text-brand-300 border border-brand-500/30'
                              : 'text-slate-300 hover:text-white hover:bg-white/5' }}">
                    العروض
                </a>

                @auth
                    <a href="{{ route('admin.dashboard') }}"
                       class="px-3 py-1.5 rounded-full transition
                              {{ request()->routeIs('admin.*')
                                  ? 'bg-brand-500/15 text-brand-300 border border-brand-500/30'
                                  : 'text-slate-300 hover:text-white hover:bg-white/5' }}">
                        لوحة التحكم
                    </a>
                    <form action="{{ route('logout') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit"
                                class="px-3 py-1.5 rounded-full text-slate-400 hover:text-rose-300 hover:bg-rose-500/10 transition">
                            خروج
                        </button>
                    </form>
                @endauth
            </nav>
        </div>
    </header>

    <main class="flex-1 w-full max-w-6xl mx-auto px-4 py-8 md:py-12">
        @yield('content')
    </main>

    <footer class="border-t border-white/5 bg-slate-950/60">
        <div class="max-w-6xl mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500">
            <div>© {{ now()->year }} {{ config('app.name', 'Tickets') }}</div>
            <div>حجز إلكتروني • تذاكر QR</div>
        </div>
    </footer>

</body>
</html>
