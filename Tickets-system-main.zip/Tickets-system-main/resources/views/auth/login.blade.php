@extends('layouts.app')

@section('title', 'تسجيل الدخول')

@section('content')
<section class="max-w-sm mx-auto py-6">
    <div class="card rounded-2xl p-6 md:p-8 space-y-5">

        <div class="text-center">
            <div class="inline-flex w-12 h-12 rounded-2xl items-center justify-center
                        bg-gradient-to-br from-brand-500 to-violet-500 mb-3">
                <svg viewBox="0 0 24 24" class="w-6 h-6 text-white" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="11" width="18" height="11" rx="2"/>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                </svg>
            </div>
            <h1 class="text-xl font-bold">دخول الإدارة</h1>
            <p class="text-xs text-slate-400 mt-1">سجل دخولك للوصول إلى لوحة التحكم</p>
        </div>

        @if ($errors->any())
            <div class="bg-rose-500/10 border border-rose-500/40 text-rose-200 text-xs rounded-xl p-3">
                {{ $errors->first() }}
            </div>
        @endif

        <form action="{{ route('login.submit') }}" method="POST" class="space-y-3">
            @csrf

            <div>
                <label class="text-xs mb-1 block text-slate-300">البريد الإلكتروني</label>
                <input type="email" name="email" value="{{ old('email') }}" required autofocus
                       class="w-full bg-slate-950/50 border border-white/10 rounded-lg px-3 py-2 text-sm
                              focus:outline-none focus:border-brand-500">
            </div>

            <div>
                <label class="text-xs mb-1 block text-slate-300">كلمة المرور</label>
                <input type="password" name="password" required
                       class="w-full bg-slate-950/50 border border-white/10 rounded-lg px-3 py-2 text-sm
                              focus:outline-none focus:border-brand-500">
            </div>

            <button type="submit" class="btn-primary w-full px-4 py-2.5 rounded-xl text-sm font-semibold">
                تسجيل الدخول
            </button>
        </form>
    </div>
</section>
@endsection
